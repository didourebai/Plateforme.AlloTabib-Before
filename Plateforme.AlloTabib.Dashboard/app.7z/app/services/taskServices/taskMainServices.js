﻿'use strict';

app.factory('taskMainServices', function ($http, appSettings) {
    var tasksManagerDataFactory = {};


    var _getAllTasks = function () {
        return $http({
            method: 'GET',
            url: appSettings.taskListUri
        }).then(function (results) {
            return results;
        });
    };

    var _addNewTask = function (task) {
        return $http({
            method: 'POST',
            url: appSettings.addTaskUri,
            data: task
        }).then(function (results) {
            return results;
        });
    };

    var _deleteTask = function (id) {
        return $http({
            method: 'DELETE',
            url: appSettings.deleteTaskUri + '/' + id
        }).then(function (results) {
            return results;
        });
    };

    var _updateTask = function (task) {
        return $http({
            method: 'PUT',
            url: appSettings.updateTaskUri,
            data: task
        }).then(function (results) {
            return results;
        });
    };

    tasksManagerDataFactory.getAllTasks = _getAllTasks;
    tasksManagerDataFactory.addNewTask = _addNewTask;
    tasksManagerDataFactory.deleteTask = _deleteTask;
    tasksManagerDataFactory.updateTask = _updateTask;

    return tasksManagerDataFactory;
});