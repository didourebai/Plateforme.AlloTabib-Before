﻿'use strict';

app.controller('homeController', function ($scope, $location) {

});