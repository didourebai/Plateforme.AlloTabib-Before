﻿'use strict';

var app = angular
  .module('app', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngClipboard',
    'ngSanitize',
    'ngTouch',
    'ngClipboard',
    'mgcrea.ngStrap',
    'ui.bootstrap',
    'mgcrea.ngStrap.popover'

  ]);

app.config(function ($routeProvider, $httpProvider) {
    $httpProvider.defaults.headers.post = {
        'Content-Type': 'application/json;charset=utf-8'
    };
    $httpProvider.defaults.headers.patch = {
        'Content-Type': 'application/json;charset=utf-8'
    };
    $httpProvider.defaults.headers.delete = {
        'Content-Type': 'application/json;charset=utf-8'
    };
    $routeProvider
        .when('/home', {
            templateUrl: '/app/views/home/home.html',
            controller: 'homeController'
        })
        .when('/demo', {
            templateUrl: '/app/views/demo/demo.html',
            controller: 'demoController'
        })
        .otherwise({
            templateUrl: '/app/views/home/home.html',
            controller: 'homeController'
        });
});

app.directive('ngEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.ngEnter);
                });

                event.preventDefault();
            }
        });
    };
});

var active = 'Active';
var inProgress = 'In Progress';
var done = 'Done';
var listStatuses = ['Active', 'In Progress', 'Done'];

var list = [
    { description: 'Create a deployment sheet on confluence with detailed step to install ATLAS.', assignee: 'Hamdi Hichem', date: '25-06-2014', status: inProgress },
    { description: 'Board open search with type.', assignee: 'Theljani Ahmed', date: '13-05-2014', status: done },
    { description: 'Add new board form.', assignee: 'Theljani Ahmed', date: '18-04-2014', status: done },
];

var listOfDevelopers = ['Theljani Ahmed', 'Cristophe Garcia', 'Manu Thibaud'];

// App Settings
var apiUri = 'http://localhost:62922/';


app.constant('appSettings', {
    taskListUri: apiUri + 'tasks',
    addTaskUri: apiUri + 'tasks/new',
    deleteTaskUri: apiUri + 'tasks/delete',
    updateTaskUri: apiUri + 'tasks/modify'
});

app.constant('defaultPageSize', {
    mainMaxPageSize: 50
});



